from queue import PriorityQueue
from errno import ENOTEMPTY
from socket import close
from turtle import distance, position, width
from GameFrame import BlueBot, Globals
from enum import Enum
import random

from GameFrame import Level, Globals, RedFlag, BlueFlag, TextObject
from Objects import DangerZone
from Objects import Red1, Red2, Red3, Red4, Red5
from Objects import Blue1, Blue2, Blue3, Blue4, Blue5
import math
import numpy as np
import pygame
WHITE =  (255,255,255)


class STATE(Enum):
    WAIT = 1
    ATTACK = 2
    JAIL_BREAK = 3
    



    





class Blue1(BlueBot):
    def __init__(self, room, x, y):
        BlueBot.__init__(self, room, x, y)
        self.initial_wait = random.randint(60, 100)
        self.wait_count = 0
        self.curr_state = STATE.WAIT
        self.col = 0
        self.row = 0
        self.end_row = 0
        self.end_col = 0
        self.width = Globals.SCREEN_WIDTH
        self.total_rows = 64

        

    
    def tick(self):
        halfway = Globals.SCREEN_WIDTH/2
        blue_flag = Globals.blue_flag
        closest, dist = self.closest_to_me()
        next_closest, next_dist = self.next_closest_to_me(closest,dist)
        if dist > 180:
            if self.has_flag:
                self.turn_towards(0, self.y)
                self.drive_forward(Globals.FAST)
                
            elif self.rect.right <= Globals.SCREEN_WIDTH / 2:
                self.turn_towards(self.starting_x + 400, self.starting_y, Globals.FAST)
                self.drive_forward(Globals.FAST)
            else:
                self.turn_towards(Globals.blue_flag.x, Globals.blue_flag.y, Globals.FAST)  #put in a code to detect any uncovered area of the flag, if all is covered then circle it
                self.drive_forward(Globals.FAST)
            closest, dist = self.closest_to_me()
        else:
            if self.x < halfway - 100:
                self.turn_towards(closest.x, closest.y, Globals.FAST)
                self.drive_forward(Globals.FAST)
                closest, dist = self.closest_to_me()
            else:
                if self.point_to_point_distance(Globals.blue_flag.x, Globals.blue_flag.y, self.x,self.y) > 180:  #messs around with it
                    self.turn_towards(-closest.x, -closest.y, Globals.FAST)
                    self.drive_forward(Globals.FAST)
                    closest, dist = self.closest_to_me()
                else:
                    self.turn_towards(Globals.blue_flag.x, Globals.blue_flag.y, Globals.FAST)
                    self.drive_forward(Globals.FAST)
                    if self.has_flag:
                        self.turn_towards(0, self.y)
                        self.drive_forward(Globals.FAST)
                        if dist < 200:
                            self.turn_towards(-closest.x, -closest.y, Globals.FAST)
                            self.drive_forward(Globals.FAST)
                    closest, dist = self.closest_to_me()
                                    
        
               
    def closest_to_me(self):   
        closest1 = Globals.red_bots[0]
        shortest_distance = self.point_to_point_distance(closest1.x,closest1.y,self.x,self.y)
        for enemy in Globals.red_bots:
            if self.point_to_point_distance(enemy.x,enemy.y,self.x,self.y) < shortest_distance: 
                closest1 = enemy
                shortest_distance = self.point_to_point_distance(closest1.x,closest1.y,self.x,self.y)
        return closest1, shortest_distance

    def go_to_jail(self,friend):
        dist_jail = self.closest_friend_to_jail()
        if (dist_jail == self.point_to_point_distance(self.x, self.y, 0, 0)) or Globals.blue_bots[1].jailed:
            stuck = self.is_self_stuck()
            if stuck == True:
                if (self.angle >= 85 and self.angle <= 95) or ((self.angle <= 10 and self.angle >= 350) or self.angle < 0):
                    self.drive_backward()
                    self.drive_backward()
                    self.turn_towards(friend.x,friend.y, Globals.FAST)
                else:
                    self.turn_towards(friend.x,friend.y, Globals.FAST)
            elif self.x <= 20 and (self.angle >= 80 and self.angle <= 100):
                self.turn_towards(friend.x, 0, Globals.FAST)
            elif self.y <= 20 and ((self.angle <= 10 and self.angle >= 350) or self.angle < 0):
                self.turn_towards(0, friend.y, Globals.FAST)
            else:
                self.turn_towards(friend.x,friend.y, Globals.FAST)
                self.drive_forward(Globals.SLOW)
        else:
            dist_jail = self.closest_friend_to_jail()
    def is_self_stuck(self):
        if not self.jailed:
            if self.x <= self.width:
                return True
            elif self.x >= Globals.SCREEN_WIDTH - self.width:
                return True
            if self.y <= self.width:
                return True
            elif self.y >= Globals.SCREEN_HEIGHT - self.height:
                return True
            else:
                return False
        else:
            return False

    def closest_enemy_to_flag(self):
        # set default bot for comparison
        closest2 = Globals.red_bots[0]
        # set flag
        flag = Globals.red_flag
        # set default distance
        dist = self.point_to_point_distance(closest2.x,closest2.y,flag.x,flag.y)

        for enemy in Globals.red_bots:
            # checks if any are closer
            if self.point_to_point_distance(enemy.x,enemy.y,flag.x,flag.y) < dist:
                # reallocates the closest bot and the distance
                closest2 = enemy
                dist = dist = self.point_to_point_distance(closest2.x,closest2.y,flag.x,flag.y)

        return closest2

    def dist_to_enemy_flag(self):
        flag = Globals.blue_flag
        dist = self.point_to_point_distance(self.x,self.y,flag.x,flag.y)
        
        return dist
    
    def next_closest_to_me(self, closest, dist):
        closest1 = Globals.red_bots[0]
        shortest_distance = self.point_to_point_distance(closest.x,closest.y,self.x,self.y)
        if shortest_distance == dist:
            closest1 = Globals.red_bots[1]
            shortest_distance = self.point_to_point_distance(closest.x,closest.y,self.x,self.y)
        for enemy in Globals.red_bots:
            if self.point_to_point_distance(enemy.x,enemy.y,self.x,self.y) < shortest_distance: 
                if self.point_to_point_distance(enemy.x,enemy.y,self.x,self.y) != dist:
                    closest1 = enemy
                    shortest_distance = self.point_to_point_distance(enemy.x,enemy.y,self.x,self.y)
        return closest1 , shortest_distance
    
    #     win = pygame.display.set_mode((Globals.SCREEN_WIDTH,Globals.SCREEN_HEIGHT))
    #     pygame.display.set_caption("A* Pathfinding")
    #     # self.turn_left()
    #     width = Globals.SCREEN_WIDTH
    #     ROWS = 64   #1280px (max screen width) / 20px (block width)
    #     halfway = Globals.SCREEN_WIDTH/2
    #     grid = self.make_grid(ROWS, width)
    #     dict = {}
    #     dict_positions = {}
    #     print("------------------------------ NEW TICK --------------------------------")
    #     active_bots,sorted_dist,sorted_bots,sorted_positions = self.sort(halfway,dict,dict_positions)
    #     close_coords = (sorted_positions[0][0], sorted_positions[0][1])
    #     # print("OLD: ", self.enemy_coords[0], ",", self.enemy_coords[1], " NEW: ", close_coords[0], ",", close_coords[1], end="\n")
    #     # print(grid)
    #     # self.update_neighbors()
        
    #     self.enemy_coords = (close_coords[0], close_coords[1])

       

    #     pos = (self.x,self.y)
    #     self.row, self.col = self.get_poss(pos, ROWS, width)
    #     spot = grid[self.row][self.col]
    #     if not start and spot != end:
    #         start = spot
    #         self.make_start()
    #     elif not end and spot != start:
    #         end = spot
    #         self.make_end()
    #     elif spot != end and spot != start:
    #         self.make_barrier()

    #     pos = (Globals.red_flag.x,Globals.red_flag.y)
    #     self.end_row, self.end_col = self.get_poss(pos, ROWS, width)
    #     spot = grid[self.end_row][self.end_col]
    #     if spot == start:
    #         start = None
    #     elif spot == end:
    #         end = None

    #     for row in grid:
    #         for spot in row:
    #             self.update_neighbours(grid)
    #     self.algorithm(lambda: self.draw(win, grid, ROWS, width), grid, start, end)   #having lambda lets you run the function inside the function

    #     start = None
    #     end = None
    #     grid = self.make_grid(ROWS, width)

    





    # def get_poss(pos, rows, width):
    #     gap = width // rows
    #     y,x = pos

    #     row = y//gap
    #     col = x//gap
    #     return row, col


   
    # def get_pos(self):
    #     return self.row, self.col

    # def is_closed(self):
    #     return self.colour == 1 #RED

    # def is_open(self):
    #     return self.colour == 2 #GREEN

    # def is_barrier(self):
    #     return self.colour == 3 #BLACK

    # def is_start(self):
    #     return self.colour == 4 #ORANGE

    # def is_end(self):
    #     return self.colour == 5 #TURQUOISE

    # def reset(self):
    #     self.colour = 6 #WHITE

    # def make_closed(self):
    #     self.colour = 7 #RED

    # def make_open(self):
    #     self.colour = 8 #GREEN

    # def make_barrier(self):
    #     self.colour = 9 #BLACK

    # def make_end(self):
    #     self.colour = 10 #TURQUOISE

    # def make_path(self):
    #     self.colour = 11 #PURPLE
    

    # def draw(self, win):
    #     pygame.draw.rect(win, self.colour, (self.x, self.y, self.width, self.width))

    # def update_neighbours(self, grid):
    #     self.neighbours = []
    #     if self.row < self.total_rows - 1 and not grid[self.row +1][self.col].is_barrier():  #DOWN
    #         self.neighbours.append(grid[self.row +1][self.col])

    #     if self.row > 0 and not grid[self.row - 1][self.col].is_barrier():   # UP
    #         self.neighbours.append(grid[self.row -1][self.col])

    #     if self.col < self.total_rows - 1 and not grid[self.row][self.col+ 1].is_barrier():  #RIGHT
    #         self.neighbours.append(grid[self.row ][self.col+1])

    #     if self.col > 0 and not grid[self.row][self.col - 1].is_barrier():  #RIGHT
    #         self.neighbours.append(grid[self.row][self.col - 1])

    # # def __lt__(self,other):
    # #     return False

    # def make_start(self):
    #     self.colour = 12 #ORANGE

    # def sort(self, halfway,dict,dict_positions):
    #     for enemy in Globals.red_bots:
    #         enemy_distance = self.point_to_point_distance(self.x,self.y, enemy.x,enemy.y)
    #         dict[enemy] = enemy_distance 
    #         dict_positions[enemy] = [enemy.x,enemy.y]

    #     print("----      NEW TICK       ----", end="\n")
    #     print("given dist: \n", str(dict.values()),end="\n")
    #     print("old dict postions: ", dict_positions.values(), end="\n")
        
    #     dict = {key: val for key, val in sorted(dict.items(), key = lambda ele: ele[1])}
    #     dict_positions = {key: val for key, val in sorted(dict_positions.items(), key = lambda ele: ele[1])}

    #     sorted_bots = list(dict.keys())  #not needed once print statements are gone
    #     sorted_dist = list(dict.values())
    #     sorted_positions = list(dict_positions.values())
        
    #     print("sorted dist: \n", sorted_dist,end="\n")
    #     print("sorted postions: \n", sorted_positions, end="\n")
    #     print("closest postion_x: \n", sorted_positions[0][0], end="\n")
        
    #     i = 0
    #     active_bots = {}

    #     while i < len(dict.keys()):  
    #         if ((sorted_positions[i][0] != 1244) and (sorted_positions[i][1] != 680)) and (sorted_positions[i][0] > halfway) and ((sorted_positions[i][1] > 185) and (sorted_positions[i][1] < Globals.SCREEN_HEIGHT - 185)):  
    #             print(sorted_bots[i], " --   ACTIVE   -- ", "position_x: ", sorted_positions[i][0], " position_y: ", sorted_positions[i][1], end="\n")
    #             active_bots[sorted_dist[i]] = [sorted_positions[i][0],sorted_positions[i][1]] 
    #         else:
    #             print(sorted_bots[i], " --  DISABLED  -- ", "position_x: ", sorted_positions[i][0], " position_y: ", sorted_positions[i][1], end="\n")
    #         i = i + 1
        
    #     sorted_dist = list(active_bots.keys()) 
    #     sorted_positions = list(active_bots.values())  
        
    #     print("closest active postion_x: \n", sorted_positions[0][0], end="\n")
    #     print("active bots: \n", active_bots, end="\n")
        
    #     return active_bots,sorted_dist,sorted_bots,sorted_positions
           
           
 
       
       
            
    
                
    
            
    # # def h_best(self, end):
    # #     x1 = self.row
    # #     y1 = self.col
    # #     x2 = end.row        #replace node with self
    # #     y2 = end.col
    # #     return abs(x1 - x2) + abs(y1 - y2)

    # # def best_first_search(self, draw, grid, start, end):

    # #     path = []
    # #     pqueue = PriorityQueue()
    # #     t = (start.row, start.col)
    # #     q = (self.h_best(start,end), t)
    # #     pqueue.put(q)

    # #     while pqueue:
    # #         #print(pqueue)
    # #         u = pqueue.get()
    # #         #print(u)
    # #         t = u[1]
    # #         grid[t[0]][t[1]].make_closed()
    # #         path.append(t)

    # #         if grid[t[0]][t[1]] == end:
    # #             self.move_best(draw, grid, path)  #replace with movement
    # #             return
    # #         else:
    # #             for neighbor in grid[t[0]][t[1]].neighbors:
    # #                 if neighbor.isVisited[0] == 0:
    # #                     neighbor.isVisited[0] = 1
    # #                     t = (neighbor.row,neighbor.col)
    # #                     q = (self.h_best(neighbor, end), t)
    # #                     pqueue.put(q)
    # #             grid[t[0]][t[1]].make_open()
    # #             grid[t[0]][t[1]].isVisited[0] = 1
                
    # # def move_best(self, draw, grid, path):
    # #     for node in path:
    # #         self.turn_towards(self.x, self.y, self.width, self.width, Globals.FAST)
    # #         self.drive_forward(Globals.FAST)
            
        
        
        
        

    # def make_grid(self,rows, width):
    #     grid = []
    #     gap = width // rows
    #     for i in range(rows):
    #         grid.append([])
    #         for j in range(rows):
    #             spot = list(i, j, gap, rows)
    #             grid[i].append(spot)

    #     return grid          
                
    # def reconstruct_path(self,came_from, current, draw):
    #     while current in came_from:
    #         current = came_from[current]
    #         current.make_path()
    #         draw()
            
    # def h(self,p1, p2):
    #     x1, y1 = p1
    #     x2, y2 = p2
    #     return abs(x1-x2) + abs(y1-y2)
        
    # def algorithm(self,draw, grid, start, end):
    #     count = 0
    #     open_set = PriorityQueue()   # returns the smallest value in the list
    #     open_set.put((0, count, start))
    #     came_from = {}
    #     g_score = {spot: float("inf") for row in grid for spot in row}
    #     g_score[start] = 0
    #     f_score = {spot: float("inf") for row in grid for spot in row}
    #     f_score[start] = self.h(start.get_pos(), end.get_pos())

    #     open_set_hash = {start}
    #     while not open_set.empty():
    #         for event in pygame.event.get():
    #             if event.type ==pygame.QUIT:
    #                 pygame.quit()
    #         current = open_set.get()[2]      # returns the best value
    #         open_set_hash.remove(current)
    #         if current == end:
    #             self.reconstruct_path(came_from, end, draw)
    #             end.make_end()
    #             start.make_start()
    #             return True

    #         for neighbour in current.neighbours:
    #             temp_g_score = g_score[current]+1

    #             if temp_g_score < g_score[neighbour]:
    #                 came_from[neighbour] = current
    #                 g_score[neighbour] = temp_g_score
    #                 f_score[neighbour] = temp_g_score + self.h(neighbour.get_pos(), end.get_pos())
    #                 if neighbour not in open_set_hash:
    #                     count += 1
    #                     open_set.put((f_score[neighbour], count, neighbour))
    #                     open_set_hash.add(neighbour)
    #                     neighbour.make_open()
    #         draw()
    #         if current != start:
    #             current.make_closed()

    #     return False              


