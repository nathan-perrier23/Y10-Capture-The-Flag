from GameFrame import BlueBot, Globals
import random
import math
import time

class Blue4(BlueBot):
    def __init__(self, room, x, y):
        BlueBot.__init__(self, room, x, y)
        self.initial_wait = random.randint(30, 90)
        self.wait_count = 0

    def tick(self):
        blue_flag = Globals.blue_flag
        halfway = Globals.SCREEN_WIDTH / 2
        dict = {}
        dict_positions = {}
        sorted_bots,sorted_dist,sorted_positions = self.sort(halfway,dict,dict_positions)
        
        if self.wait_count < self.initial_wait:
            self.wait_count += 1
        else:
                
            if sorted_dist[0] > 180:
                if self.has_flag:
                    self.turn_towards(0, self.y)
                    self.drive_forward(Globals.FAST)
                    
                elif self.rect.right <= Globals.SCREEN_WIDTH / 2:
                    self.turn_towards(self.starting_x + 400, self.starting_y, Globals.FAST)
                    self.drive_forward(Globals.FAST)
                else:
                    self.turn_towards(Globals.blue_flag.x, Globals.blue_flag.y, Globals.FAST)  #put in a code to detect any uncovered area of the flag, if all is covered then circle it
                    self.drive_forward(Globals.FAST)
            else:
                if self.x < halfway - 100 and sorted_dist[0] > Globals.SCREEN_WIDTH / 4:  #check!!
                    self.turn_towards(sorted_positions[0][0], sorted_positions[0][1], Globals.FAST)
                    self.drive_forward(Globals.FAST)
                elif self.x < halfway - 100 and sorted_dist[0] <  Globals.SCREEN_WIDTH / 4:
                    self.turn_towards(Globals.blue_flag.x, Globals.blue_flag.y, Globals.FAST)  #put in a code to detect any uncovered area of the flag, if all is covered then circle it
                    self.drive_forward(Globals.FAST)
                else:
                    if self.point_to_point_distance(Globals.blue_flag.x, Globals.blue_flag.y, self.x,self.y) > 180:  #messs around with it
                        self.turn_towards(-sorted_positions[0][0], -sorted_positions[0][1], Globals.FAST)
                        self.drive_forward(Globals.FAST)
                    else:
                        self.turn_towards(Globals.blue_flag.x, Globals.blue_flag.y, Globals.FAST)
                        self.drive_forward(Globals.FAST)
                        if self.has_flag:
                            self.turn_towards(0, self.y)
                            self.drive_forward(Globals.FAST)
                            if sorted_dist[0] < 200:
                                self.turn_towards(-sorted_positions[0][0], -sorted_positions[0][1], Globals.FAST)
                                self.drive_forward(Globals.FAST)
                
    

    def sort(self, halfway,dict,dict_positions):
        for enemy in Globals.red_bots:
            enemy_distance = self.point_to_point_distance(self.x,self.y, enemy.x,enemy.y)
            dict[enemy] = enemy_distance 
            dict_positions[enemy] = [enemy.x,enemy.y]
        
        dict = {key: val for key, val in sorted(dict.items(), key = lambda ele: ele[1])}
        dict_positions = {key: val for key, val in sorted(dict_positions.items(), key = lambda ele: ele[1])}

        sorted_bots = list(dict.keys())
        sorted_dist = list(dict.values())
        sorted_positions = list(dict_positions.values())
        
        return sorted_bots,sorted_dist,sorted_positions
    
