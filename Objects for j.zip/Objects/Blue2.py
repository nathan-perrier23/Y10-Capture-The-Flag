from ast import Global
from calendar import c
import dis
from pickle import FALSE, TRUE
from GameFrame import BlueBot, Globals
from enum import Enum
import datetime
import math


class STATE(Enum):
    WAIT = 1
    ATTACK = 2


class Blue2(BlueBot):
    def __init__(self, room, x, y):
        BlueBot.__init__(self, room, x, y)
        self.curr_state = STATE.WAIT
        self.stuck = False
        self.enemy_coords = (0,0)
        self.time_after = datetime.datetime.now()
    
    def tick(self):
        halfway = Globals.SCREEN_WIDTH/2
        dict, dict_positions = {}, {}
        dict_positions, active_bots,sorted_dist,sorted_bots,sorted_positions = self.sort(halfway,dict,dict_positions, Globals.red_flag)
        if active_bots:
            close_coords = (sorted_positions[0][0], sorted_positions[0][1])
            distance_traveled = self.point_to_point_distance(close_coords[0],close_coords[1], self.enemy_coords[0], self.enemy_coords[1])
            speed = self.get_speed(distance_traveled)
            my_x, my_y = self.x, self.y
            x4 = my_x + ((abs(my_x - close_coords[0]))/2)
            active = True   
        else:
            active = False   

        if active == True: 
            if active_bots:  #needed?
                if (self.x < (halfway - 80)): 
                    dist_to_self, dist_to_enemy,x4,y4 = self.calculate(x4,my_x,my_y,self.enemy_coords[0], self.enemy_coords[1], close_coords[0], close_coords[1])
                    if (dist_to_self == dist_to_enemy) or ((abs(dist_to_enemy - dist_to_self)) <= 45): #original is 70 (bias)
                        self.drive_to_enemy(speed,x4,y4)
                    else:
                        if y4 >= Globals.SCREEN_HEIGHT:
                            dist_to_self = dist_to_enemy
                            y4 = Globals.SCREEN_HEIGHT
                            self.drive_to_enemy(speed,x4,y4)
                        elif y4 <= 0:
                            dist_to_self = dist_to_enemy
                            y4 = 0
                            self.drive_to_enemy(speed,x4,y4)
                            
                        else:
                            if (dist_to_self > dist_to_enemy) and (abs(dist_to_enemy - dist_to_self) > 45):
                                x4 = my_x + ((abs(x4 - close_coords[0]))-(dist_to_self-dist_to_enemy)) #move x4 left
                                dist_to_self, dist_to_enemy,x4,y4 = self.calculate(x4,my_x,my_y,self.enemy_coords[0], self.enemy_coords[1], close_coords[0], close_coords[1])

                            elif (dist_to_enemy > dist_to_self) and (abs(dist_to_enemy - dist_to_self) > 45):
                                x4 = my_x + ((abs(x4 - close_coords[0]))+(dist_to_enemy-dist_to_self)) #move x4 right 
                                dist_to_self, dist_to_enemy,x4,y4 = self.calculate(x4,my_x,my_y,self.enemy_coords[0], self.enemy_coords[1], close_coords[0], close_coords[1])
                    
                            self.drive_to_enemy(speed,x4,y4)
                
                else:
                    self.turn_towards(Globals.red_flag.x,Globals.red_flag.y, Globals.FAST)
                    self.drive_forward(Globals.FAST)
            else: 
                self.turn_towards(Globals.red_flag.x,Globals.red_flag.y, Globals.FAST)
                self.drive_forward(Globals.FAST)
                
        else:
            if self.point_to_point_distance(Globals.red_flag.x,Globals.red_flag.y,self.x,self.y) > 50:
                self.turn_towards(Globals.red_flag.x, Globals.red_flag.y, Globals.FAST)
                self.drive_forward(Globals.FAST)
            else:
                self.turn_towards(Globals.red_flag.x, Globals.red_flag.y, Globals.MEDIUM)
                self.drive_forward(Globals.SLOW)

        if active == True:
            self.enemy_coords = (close_coords[0], close_coords[1])







    # def tick(self):
    #     # stuck = self.is_self_stuck()
    #     # closest_jail , dist_jail = self.closest_friend_to_jail()
    #     # closest = self.closest_enemy_to_flag()   #good (defender and jailer)
    #     dict = {}   
    #     dict_positions = {}
    #     halfway = Globals.SCREEN_WIDTH / 2 
    #     active_bots,sorted_dist,sorted_bots,sorted_positions = self.sort(halfway, dict, dict_positions)
    #     close_coords = (sorted_positions[0][0], sorted_positions[0][1])
    #     print("OLD: ", self.last_sorted_positions, "NEW: ", sorted_positions[0][0], sorted_positions[0][1])
    #     my_x = self.x
    #     my_y = self.y
    #     # distance = self.closest_to_me()
    #     # red_flag = Globals.red_flag
        
    #     # if self.point_to_point_distance(0, Globals.SCREEN_HEIGHT/2,self.x,self.y) > halfway - 50:
    #     #     self.turn_towards(red_flag.x, red_flag.y, Globals.FAST)
    #     #     self.drive_forward(Globals.FAST)
    #     # else:

    #     dist_to_self, dist_to_enemy,x4,y4 = self.calculate(my_x,my_y,self.last_sorted_positions[0][0], self.last_sorted_positions[0][1], sorted_positions[0][0], sorted_positions[0][1])
    #     if abs(dist_to_self - dist_to_enemy) >= 30 or dist_to_self == dist_to_enemy:
    #         # if x4 <= self.x:  #assuming self.x is to the left of enemy.x
    #         #     pass 
    #         # elif x4 >= sorted_positions[0][0]:
    #         #     pass
    #         # else:
    #         if dist_to_self > dist_to_enemy:
    #             x4 = x4/2 #move x4 left
    #             dist_to_self, dist_to_enemy,x4,y4 = self.calculate(my_x,my_y,self.last_sorted_positions[0][0], self.last_sorted_positions[0][1], sorted_positions[0][0], sorted_positions[0][1]) #repeat function
    #             #would it keep on looping?
    #         else:
    #             x4 = x4*2 #move x4 right
    #             dist_to_self, dist_to_enemy,x4,y4 = self.calculate(my_x,my_y,self.last_sorted_positions[0][0], self.last_sorted_positions[0][1], sorted_positions[0][0], sorted_positions[0][1]) #repeat function
    #     else:
    #         self.turn_towards(x4,y4, Globals.FAST)
    #         self.drive_forward(Globals.FAST) #match enemy speed
    #         # dist_traveled = self.point_to_point_distance(self.last_sorted_positions[0][0],self.last_sorted_positions[0][1], sorted_positions[0][0],sorted_positions[0][1])
    #         # time_taken = 1 #how do i accuratly measure the time between the two points?
    #         # v = dist_traveled / time_taken
    #         # if v <=3:
    #         #     self.drive_forward(Globals.SLOW)
    #         # elif v > 3 and v <= 7:
    #         #     self.drive_forward(Globals.MEDIUM)
    #         # else:
    #         #     self.drive_forward(Globals.FAST) #match enemy speed
        
    #     self.last_sorted_positions = ((close_coords[0], close_coords[1]))
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            # for friend in Globals.blue_bots:
            #     if friend.jailed:
            #         if (dist_jail == self.point_to_point_distance(self.x, self.y, 0, 0)) or Globals.blue_bots[2].jailed:
            #             stuck = self.is_self_stuck()
            #             if stuck == True:
            #                 self.drive_backward()
            #                 self.drive_backward()
            #                 self.turn_towards(friend.x,friend.y, Globals.FAST)

            #             # elif self.x <= 20 and (self.angle >= 80 and self.angle <= 100):
            #             #     self.turn_towards(friend.x, 0, Globals.FAST)
            #             # elif self.y <= 20 and (self.angle <= 10 and self.angle >= 350):
            #             #     self.turn_towards(0, friend.y, Globals.FAST)
            #             else:
            #                 self.turn_towards(friend.x,friend.y, Globals.FAST)
            #                 self.drive_forward(Globals.SLOW)
            #         else:
            #             closest_jail , dist_jail = self.closest_friend_to_jail()

            # if stuck == True:
            #     self.drive_backward()   
                       
            # for bot in Globals.red_bots:
            #     if bot.has_flag and bot is not self:
            #         self.turn_towards(bot.x, bot.y, Globals.FAST)
            #         self.drive_forward(Globals.FAST) 
        
            # if distance < halfway - 80:
            #     self.turn_towards(closest.x, closest.y, Globals.FAST)
            #     self.drive_forward(Globals.FAST)  
            # else:   
            #     if self.point_to_point_distance(red_flag.x,red_flag.y,self.x,self.y) > 50:
            #         self.turn_towards(Globals.red_flag.x, Globals.red_flag.y, Globals.FAST)
            #         self.drive_forward(Globals.FAST)
            #     else:
            #         self.turn_towards(Globals.red_flag.x, Globals.red_flag.y, Globals.MEDIUM)
            #         self.drive_forward(Globals.SLOW)
            #         closest = self.closest_enemy_to_flag()
            #         distance = self.closest_to_me()
        
    # def closest_to_me(self):   
    #     closest1 = Globals.red_bots[0]
    #     shortest_distance = self.point_to_point_distance(closest1.x,closest1.y,self.x,self.y)
    #     for enemy in Globals.red_bots:
    #         if self.point_to_point_distance(enemy.x,enemy.y,self.x,self.y) < shortest_distance: 
    #             closest1 = enemy
    #             shortest_distance = self.point_to_point_distance(closest1.x,closest1.y,self.x,self.y)
    #     return shortest_distance

    def is_self_stuck(self):
        if not self.jailed:
            if self.x <= 0:
                return True
            elif self.x >= Globals.SCREEN_WIDTH - self.width:
                return True
            if self.y <= 0:
                return True
            elif self.y >= Globals.SCREEN_HEIGHT - self.height:
                return True
            else:
                return False
        else:
            return False

    def closest_enemy_to_flag(self): #can combine wit the closest to jail (send a varble that you want to see who is closest to)
        # set default bot for comparison
        closest2 = Globals.red_bots[0]
        # set flag
        flag = Globals.red_flag
        # set default distance
        dist = self.point_to_point_distance(closest2.x,closest2.y,flag.x,flag.y)
        
        old_enemy_position_to_flag = (closest2.x,closest2.y)

        for enemy in Globals.red_bots:
            # checks if any are closer
            if self.point_to_point_distance(enemy.x,enemy.y,flag.x,flag.y) < dist:
                # reallocates the closest bot and the distance
                closest2 = enemy
                dist = dist = self.point_to_point_distance(closest2.x,closest2.y,flag.x,flag.y)
                old_enemy_position_to_flag = (closest2.x,closest2.y)

        return closest2, old_enemy_position_to_flag
    
    def go_to_jail(self, friend):
        dist_jail = self.closest_friend_to_jail()
        if (dist_jail == self.point_to_point_distance(self.x, self.y, 0, 0)) or Globals.blue_bots[2].jailed:
            stuck = self.is_self_stuck()
            if stuck == True:
                if (self.angle >= 85 and self.angle <= 95) or ((self.angle <= 10 and self.angle >= 350) or self.angle < 0):
                    self.drive_backward()
                    self.drive_backward()
                    self.turn_towards(friend.x,friend.y, Globals.FAST)
                else:
                    self.turn_towards(friend.x,friend.y, Globals.FAST)
            elif self.x <= 20 and (self.angle >= 80 and self.angle <= 100):
                self.turn_towards(friend.x, 0, Globals.FAST)
            elif self.y <= 20 and ((self.angle <= 10 and self.angle >= 350) or self.angle < 0):
                self.turn_towards(0, friend.y, Globals.FAST)
            else:
                self.turn_towards(friend.x,friend.y, Globals.FAST)
                self.drive_forward(Globals.SLOW)
        else:
            dist_jail = self.closest_friend_to_jail()
    
    def get_speed(self, distance):
        speed = distance  #the distance between two points corrolates with the speed of the bot
        if speed <= 3:
            return 1
        elif speed > 3 and speed <= 7:
            return 2
        elif speed > 7:
            return 3
    
    def drive_to_enemy(self,speed,x4,y4):
        self.turn_towards(x4,y4, Globals.FAST)   
        if speed == 1:
            self.drive_forward(Globals.SLOW)
        elif speed == 2:
            self.drive_forward(Globals.MEDIUM)
        else:
            self.drive_forward(Globals.FAST)
    
    def closest_friend_to_jail(self):
        # set default bot for comparison
        closest = Globals.blue_bots[0]
        # set flag
        jail_x = 0
        jail_y = 0
        # set default distance
        
        dist = self.point_to_point_distance(self.x, self.y, jail_x, jail_y)

        for friends in Globals.blue_bots:
            if (friends == Globals.blue_bots[1]) or (friends == Globals.blue_bots[2]):
            # checks if any are closer
                if self.point_to_point_distance(friends.x, friends.y, jail_x, jail_y) < dist:
                    # reallocates the closest bot and the distance
                    closest = friends
                    dist = dist = self.point_to_point_distance(closest.x, closest.y, jail_x, jail_y)

        return closest, dist
    
    def sort(self, halfway,dict,dict_positions, object1):
        for enemy in Globals.red_bots:
            enemy_distance = self.point_to_point_distance(object1.x,object1.y, enemy.x,enemy.y)
            dict[enemy] = enemy_distance 
            dict_positions[enemy] = [enemy.x,enemy.y]
        
        dict = {key: val for key, val in sorted(dict.items(), key = lambda ele: ele[1])}
        dict_positions = {key: val for key, val in sorted(dict_positions.items(), key = lambda ele: ele[1])}

        sorted_bots = list(dict.keys())  #not needed once print statements are gone
        sorted_dist = list(dict.values())
        sorted_positions = list(dict_positions.values())
        
        i = 0
        
        active_bots = {}
        while i < len(dict.keys()):  
            if sorted_positions[i][0] < halfway + 105: #less than half way  
                active_bots[sorted_dist[i]] = [sorted_positions[i][0],sorted_positions[i][1]]   
            i = i + 1  
            
        sorted_dist = list(active_bots.keys()) 
        sorted_positions = list(active_bots.values()) 
        
        return dict_positions, active_bots,sorted_dist,sorted_bots,sorted_positions
    
    def gradient(self,x1,y1,x2,y2):
        gradient = (y2 - y1) / (x2 - x1)
        return gradient
    
    def calculate(self,x4, my_x,my_y, last_sorted_positions_x, last_sorted_positions_y,sorted_positions_x,sorted_positions_y):
        m = self.gradient(last_sorted_positions_x,last_sorted_positions_y,sorted_positions_x,sorted_positions_y) #x2,y2 == the enemy
        c = sorted_positions_y - m*sorted_positions_x
        y4 = m*x4 + c #calculates nubers that are larger than the max y axis
        y4 = abs(y4)
        dist_to_self = self.point_to_point_distance(my_x,my_y,x4,y4)
        dist_to_enemy = self.point_to_point_distance(sorted_positions_x,sorted_positions_y,x4,y4)
        return dist_to_self,dist_to_enemy,x4,y4
        
            
            